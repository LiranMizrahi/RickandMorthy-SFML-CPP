
#include "State.h"
class LevelUpState:  State {
public:
    LevelUpState();
    void openstate(sf::RenderWindow &m_window, bool isplayerwin)override;


};

