#include "MenuState.h"
#include "Controller.h"
int main()
{


	//auto a = MenuState();
 //  a.OpenMenu();


	auto controller = Controller();
	controller.run();
	
}

