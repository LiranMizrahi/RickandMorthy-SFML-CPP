//
// Created by Liran Mizrahi on 14/01/2021.
//

#include "State.h"

State::State(const sf::Texture & sprite, const sf::SoundBuffer & sound):m_stateBackround(sprite),m_stateSound(sound) {


}
